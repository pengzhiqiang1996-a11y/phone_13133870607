(function () {
  'use strict';

  if (window.__biliScraperLoaded) return;
  window.__biliScraperLoaded = true;

  const allComments = [];
  const TARGET = '/x/v2/reply';

  const origFetch = window.fetch.bind(window);
  window.fetch = function () {
    const args = arguments;
    const url = (args[0] && args[0].url) ? args[0].url : (args[0] || '');
    const p = origFetch.apply(window, args);
    if (typeof url === 'string' && url.indexOf(TARGET) !== -1) {
      p.then(function (res) {
        res.clone().json().then(function (data) {
          const replies = data && data.data && data.data.replies;
          if (Array.isArray(replies)) parseReplies(replies);
        }).catch(function () {});
      }).catch(function () {});
    }
    return p;
  };

  const origOpen = XMLHttpRequest.prototype.open;
  const origSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (m, url) {
    this._biliUrl = url;
    return origOpen.apply(this, arguments);
  };
  XMLHttpRequest.prototype.send = function () {
    this.addEventListener('load', function () {
      if (this._biliUrl && this._biliUrl.indexOf(TARGET) !== -1) {
        try {
          const data = JSON.parse(this.responseText);
          const replies = data && data.data && data.data.replies;
          if (Array.isArray(replies)) parseReplies(replies);
        } catch (e) {}
      }
    });
    return origSend.apply(this, arguments);
  };

  function parseReplies(replies) {
    let added = 0;
    for (let i = 0; i < replies.length; i++) {
      const r = replies[i];
      const rpid = r.rpid_str;
      if (allComments.some(function (c) { return c.rpid === rpid; })) continue;
      allComments.push({
        rpid: rpid,
        uname: (r.member || {}).uname || '',
        message: (r.content || {}).message || '',
        like: r.like || 0,
        time: new Date(r.ctime * 1000).toLocaleString('zh-CN'),
        level: '\u4e3b\u8bc4\u8bba'
      });
      added++;
      const subs = r.replies || [];
      for (let j = 0; j < subs.length; j++) {
        const s = subs[j];
        const srpid = s.rpid_str;
        if (allComments.some(function (c) { return c.rpid === srpid; })) continue;
        allComments.push({
          rpid: srpid,
          uname: (s.member || {}).uname || '',
          message: (s.content || {}).message || '',
          like: s.like || 0,
          time: new Date(s.ctime * 1000).toLocaleString('zh-CN'),
          level: '\u5b50\u8bc4\u8bba'
        });
        added++;
      }
    }
    if (added > 0) updatePanel();
  }

  function exportCSV() {
    const pageUrl = window.location.href;
    const lines = [[
      '\u7528\u6237\u540d',
      '\u8bc4\u8bba\u5185\u5bb9',
      '\u70b9\u8d5e\u6570',
      '\u5c42\u7ea7',
      '\u65f6\u95f4',
      '\u89c6\u9891\u7f51\u5740'
    ].join(',')];
    for (let i = 0; i < allComments.length; i++) {
      const c = allComments[i];
      lines.push([
        '"' + c.uname.replace(/"/g, '""') + '"',
        '"' + c.message.replace(/"/g, '""') + '"',
        c.like,
        c.level,
        '"' + c.time + '"',
        '"' + pageUrl + '"'
      ].join(','));
    }
    const blob = new Blob(['\uFEFF' + lines.join('\n')], { type: 'text/csv' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'bili_comments_' + Date.now() + '.csv';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  }

  function exportJSON() {
    const pageUrl = window.location.href;
    const data = allComments.map(function (c) {
      return Object.assign({}, c, { pageUrl: pageUrl });
    });
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'bili_comments_' + Date.now() + '.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  }

  function injectPanel() {
    if (document.getElementById('bili-scraper-panel')) return;
    const panel = document.createElement('div');
    panel.id = 'bili-scraper-panel';
    panel.style.cssText = 'position:fixed;bottom:24px;right:24px;z-index:2147483647;background:#fff;border:1px solid #e0e0e0;border-radius:12px;padding:14px 18px;min-width:210px;box-shadow:0 4px 20px rgba(0,0,0,.18);font:13px/1.6 sans-serif;color:#333';
    panel.innerHTML =
      '<div style="font-weight:700;font-size:14px;margin-bottom:6px">\uD83D\uDCCB B\u7ad9\u8bc4\u8bba\u6293\u53d6</div>'
      + '<div id="bili-count" style="color:#555;margin-bottom:10px">\u5df2\u6355\u83b7\uff1a0 \u6761</div>'
      + '<div style="display:flex;gap:8px;margin-bottom:8px">'
      + '<button id="bili-csv" style="flex:1;padding:6px 0;border:1px solid #ccc;border-radius:6px;cursor:pointer;background:#f5f5f5;font-size:12px">\u5bfc\u51fa CSV</button>'
      + '<button id="bili-json" style="flex:1;padding:6px 0;border:1px solid #ccc;border-radius:6px;cursor:pointer;background:#f5f5f5;font-size:12px">\u5bfc\u51fa JSON</button>'
      + '</div>'
      + '<div style="font-size:11px;color:#999">\u6ed1\u52a8\u9875\u9762\u52a0\u8f7d\u66f4\u591a</div>'
      + '<div style="margin-top:5px;font-size:10px;color:#bbb">\u5c0f\u53ef\u8010\u6559\u4f60\u5b66 RPA \u4ea4\u6d41 13133870607</div>';
    document.body.appendChild(panel);
    document.getElementById('bili-csv').onclick = exportCSV;
    document.getElementById('bili-json').onclick = exportJSON;
  }

  function updatePanel() {
    const el = document.getElementById('bili-count');
    if (el) el.textContent = '\u5df2\u6355\u83b7\uff1a' + allComments.length + ' \u6761';
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', injectPanel);
  } else {
    injectPanel();
  }

})();
