// 这个文件运行在 content script 隔离环境
// 唯一的任务：把 inject.js 用 <script> 标签注入到页面真实环境里
(function () {
  const script = document.createElement('script');
  script.src = chrome.runtime.getURL('inject.js');
  script.onload = function () {
    script.remove(); // 注入后自动移除标签，保持干净
  };
  // 必须在 <head> 或 <html> 还没加载完之前插入
  const target = document.head || document.documentElement;
  target.appendChild(script);
})();
