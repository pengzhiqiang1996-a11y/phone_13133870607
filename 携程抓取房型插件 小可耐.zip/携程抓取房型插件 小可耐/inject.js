/*
 * inject.js —— 真正的拦截与导出逻辑（运行在页面真实环境 main world）
 * 作者 13133870607
 *
 * 拦截携程 getHotelRoomListInland 接口，解析房型/面积/床型/早餐/取消/付款/价格/库存，
 * 右下角悬浮按钮一键导出 Excel 可读 CSV（带BOM防中文乱码）。
 */
(function () {
    'use strict';

    let 缓存房型数据 = [];

    // ============ 一、拦截 fetch ============
    const 原始fetch = window.fetch;
    window.fetch = async function (...参数) {
        const 响应 = await 原始fetch.apply(this, 参数);
        const 地址 = (参数[0] && 参数[0].url) ? 参数[0].url : 参数[0];
        if (typeof 地址 === 'string' && 地址.includes('getHotelRoomListInland')) {
            响应.clone().json().then(数据 => {
                try { 解析房型(数据); } catch (e) { console.warn('【小可耐】fetch解析失败', e); }
            }).catch(() => {});
        }
        return 响应;
    };

    // ============ 二、拦截 XHR（双保险）============
    const 原始open = XMLHttpRequest.prototype.open;
    const 原始send = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.open = function (方法, 地址) {
        this.__请求地址 = 地址;
        return 原始open.apply(this, arguments);
    };
    XMLHttpRequest.prototype.send = function () {
        this.addEventListener('load', function () {
            if (this.__请求地址 && this.__请求地址.includes('getHotelRoomListInland')) {
                try { 解析房型(JSON.parse(this.responseText)); }
                catch (e) { console.warn('【小可耐】XHR解析失败', e); }
            }
        });
        return 原始send.apply(this, arguments);
    };

    // ============ 三、核心解析 ============
    function 清洗(文本) {
        return (文本 || '').replace(/「|」|『|』/g, '');
    }

    function 解析房型(数据) {
        const 数据体 = (数据 && 数据.data) ? 数据.data : {};
        const 物理房型表 = 数据体.physicRoomMap || {};   // 物理房型属性
        const 可售房型表 = 数据体.saleRoomMap || {};      // 可售产品(含价格)
        const 入住信息 = 数据体.searchBoxInfo || {};

        const 行列表 = [];
        for (const 键 in 可售房型表) {
            const 产品 = 可售房型表[键];
            const 物理房型 = 物理房型表[产品.physicalRoomId] || {};
            const 价格 = 产品.priceInfo || {};
            const 预订 = 产品.bookingStatusInfo || {};

            行列表.push({
                房型名称: 清洗(物理房型.name),
                roomToken: 产品.roomCode || '',
                面积: (物理房型.areaInfo || {}).title || '',
                窗户: (物理房型.windowInfo || {}).title || '',
                床型: (物理房型.bedInfo || {}).title || '',
                楼层: (物理房型.floorInfo || {}).title || '',
                吸烟: (物理房型.smokeInfo || {}).title || '',
                早餐: (产品.mealInfo || {}).title || '',
                取消政策: (产品.cancelInfo || {}).title || '',
                付款方式: (产品.paymentInfo || {}).subTitle || '',
                是否立即确认: (产品.confirmInfo || {}).title || '',
                实付价: 价格.price != null ? 价格.price : '',
                划线价: 价格.deletePricewithOutCurrency || '',
                剩余房量: 预订.remainRoomQuantity != null ? 预订.remainRoomQuantity : '',
                是否售罄: 预订.isFullRoom ? '是' : '否',
                入住日期: 入住信息.checkIn || '',
                离店日期: 入住信息.checkOut || '',
                入住人数: 入住信息.adult != null ? 入住信息.adult : ''
            });
        }

        // 售罄沉底，其余按实付价升序
        行列表.sort((a, b) => {
            if (a.是否售罄 !== b.是否售罄) return a.是否售罄 === '是' ? 1 : -1;
            return (a.实付价 || 99999) - (b.实付价 || 99999);
        });

        缓存房型数据 = 行列表;
        console.log(`【小可耐】已抓到 ${行列表.length} 个可售产品`, 行列表);
        提示坑位(行列表);
        刷新按钮文字();
    }

    // ============ 四、自动避坑提示 ============
    // 同物理房型内，若某产品价格更高却“不可取消”，提醒避开
    function 提示坑位(行列表) {
        const 分组 = {};
        行列表.forEach(行 => { (分组[行.房型名称] = 分组[行.房型名称] || []).push(行); });
        const 坑 = [];
        Object.values(分组).forEach(组 => {
            组.forEach(甲 => 组.forEach(乙 => {
                if (甲.实付价 > 乙.实付价 &&
                    甲.取消政策.includes('不可取消') &&
                    !乙.取消政策.includes('不可取消')) {
                    坑.push(`${甲.房型名称}(${甲.roomToken}) ¥${甲.实付价}不可取消，不如 ${乙.roomToken} ¥${乙.实付价}可退`);
                }
            }));
        });
        if (坑.length) console.warn('【小可耐·避坑提示】\n' + [...new Set(坑)].join('\n'));
    }

    // ============ 五、导出 CSV ============
    function 导出CSV() {
        if (!缓存房型数据.length) {
            alert('还没抓到房型数据，请先滚动页面让房型列表加载完成，再点导出。');
            return;
        }
        const 表头 = Object.keys(缓存房型数据[0]);
        const 包裹 = v => `"${String(v == null ? '' : v).replace(/"/g, '""')}"`;
        const 内容 = [表头.join(',')]
            .concat(缓存房型数据.map(行 => 表头.map(列 => 包裹(行[列])).join(',')))
            .join('\n');

        const 时间戳 = new Date().toLocaleString('zh-CN').replace(/[\/:\s]/g, '');
        const 链接 = document.createElement('a');
        链接.href = URL.createObjectURL(new Blob(['\ufeff' + 内容], { type: 'text/csv;charset=utf-8' }));
        链接.download = `携程房型_${时间戳}.csv`;
        链接.click();
    }

    // ============ 六、悬浮按钮 ============
    function 创建按钮() {
        if (document.getElementById('小可耐导出按钮')) return;
        if (!document.body) return;
        const 按钮 = document.createElement('button');
        按钮.id = '小可耐导出按钮';
        按钮.textContent = '导出房型CSV 交流13133870607';
        按钮.style.cssText = [
            'position:fixed', 'right:24px', 'bottom:90px', 'z-index:999999',
            'padding:10px 16px', 'background:#2577e3', 'color:#fff',
            'border:none', 'border-radius:8px', 'cursor:pointer',
            'font-size:14px', 'box-shadow:0 2px 8px rgba(0,0,0,.2)',
            'font-family:sans-serif'
        ].join(';');
        按钮.onclick = 导出CSV;
        document.body.appendChild(按钮);
    }

    function 刷新按钮文字() {
        const 按钮 = document.getElementById('小可耐导出按钮');
        if (按钮) 按钮.textContent = `导出房型CSV(${缓存房型数据.length})`;
    }

    // 携程是单页应用，定时兜底确保按钮存在
    setInterval(创建按钮, 1500);

    console.log('【小可耐】携程房型抓取器已注入，作者 13133870607');
})();
