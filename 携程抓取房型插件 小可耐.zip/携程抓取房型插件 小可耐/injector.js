/*
 * injector.js —— 注入器
 * 作者 13133870607
 *
 * 【为什么需要这个文件】
 * Chrome 扩展的 content script 运行在“隔离世界”(isolated world)，
 * 它有自己独立的 window，和页面真实的 window 不是同一个。
 * 如果直接在 content script 里改 window.fetch，改的是隔离世界的 fetch，
 * 页面发出的真实请求根本不经过它，自然拦不到。
 *
 * 正确做法：用 content script 往页面里插一个 <script> 标签，
 * 让 inject.js 在“页面真实世界”(main world) 里执行，
 * 这样它改的才是页面真正用的 window.fetch / XMLHttpRequest。
 */
(function () {
    'use strict';
    const 脚本 = document.createElement('script');
    脚本.src = chrome.runtime.getURL('inject.js');
    脚本.onload = function () { this.remove(); }; // 注入后即移除标签，保持DOM干净
    (document.head || document.documentElement).appendChild(脚本);
})();
